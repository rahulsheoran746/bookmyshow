from django.contrib import admin
from book_my_show.authenticate.models.user_model import UserModel


admin.site.register(UserModel)
