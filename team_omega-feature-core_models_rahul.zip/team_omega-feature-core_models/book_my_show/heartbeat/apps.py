from django.apps import AppConfig


class HeartbeatConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "book_my_show.heartbeat"
