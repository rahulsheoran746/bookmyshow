from enum import Enum


class AppEnvironment(Enum):
    Local = "Local"
    Development = "Development"
    Production = "Production"
